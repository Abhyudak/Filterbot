from Alita.tr_engine.tr_engine import lang_dict, tlang


async def useless_func():
    return lang_dict, tlang
